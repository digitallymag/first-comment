// var inputs = document.getElementById("input-one");

// let validateForm = () => {
//     if(inputs == undefined) {
//         console.log("Works")
//         document.getElementById("input-one").classList.add("is-invalid");
//     } else {
//         console.log("no work")
//     };
//     alert("no bug");
//     return;
// };